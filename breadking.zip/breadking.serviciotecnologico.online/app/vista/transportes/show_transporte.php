<?php
session_start();
if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login.php");
}
require '../../negocio/NInsumo.php';
require '../../negocio/NProveedor.php';
$insumo = new DInsumo();
$proveedor = new DProveedor();

$id_transporte = $_GET['Id'];
$fecha = $_GET['F'];
$usuario = $_GET['U'];
$estado = $_GET['E'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bread King</title>
    <!-- PACE-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/PACE/themes/blue/pace-theme-flash.css">
    <script type="text/javascript" src="../../../public/plugins/PACE/pace.min.js"></script>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/bootstrap/dist/css/bootstrap.min.css">
    <!-- Fonts-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/themify-icons/themify-icons.css">
    <!-- Malihu Scrollbar-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css">
    <!-- Animo.js-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/animo.js/animate-animo.min.css">

    <!-- Bootstrap Progressbar-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css">
    <!-- Toastr-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/toastr/toastr.min.css">
    <!-- Primary Style-->
    <link rel="stylesheet" type="text/css" href="../../../public/build/css/second-layout.css">
    <!-- Bootstrap DateTimePicker-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
    <!-- DataTables-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-buttons-bs/css/buttons.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-colreorder-bs/css/colReorder.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-responsive-bs/css/responsive.bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../../../public/build/css/style.css">
</head>
<body data-sidebar-color="sidebar-light" class="sidebar-light">
<!-- Header start-->
<header>
    <a href="index_transportes.php" class="brand pull-left">
        <h2>BREAD KING</h2></a><a href="javascript:;" role="button"
                                  class="hamburger-menu pull-left visible-xs"><span></span></a>

    <ul class="notification-bar list-inline pull-right">
        <li class="visible-xs"><a href="javascript:;" role="button" class="header-icon search-bar-toggle"><i
                        class="ti-search"></i></a></li>
        <li class="visible-lg"><a href="javascript:;" role="button" class="header-icon fullscreen-toggle"><i
                        class="ti-fullscreen"></i></a></li>

        <li><a href="../logout.php" role="button" class="header-icon"><i class="ti-power-off"></i></a></li>
    </ul>
</header>
<!-- Header end-->
<div class="main-container">
    <!-- Main Sidebar start-->
    <aside data-mcs-theme="minimal-dark" class="main-sidebar mCustomScrollbar">
        <div class="user">

            <h4 class="fs-14 text-muted mt-15 mb-5 fw-300"><?php echo $_SESSION['nombre'] ?></h4>
            <p class="fs-13 mb-0 text-muted"></p>
        </div>
        <?php include("../menu.html"); ?>
    </aside>
    <!-- Main Sidebar end-->
    <div class="page-container">
        <div class="page-header clearfix">
            <div class="pull-left">
                <h4 class="mt-0 mb-5">Transportes</h4>
                <ol class="breadcrumb mb-0">
                    <li><a href="#">Transportar</a></li>
                    <li><a href="#">Transportes</a></li>
                    <li><a href="index_transportes.php">Listado de Transporte</a></li>
                    <li class="active">Transporte</li>
                </ol>
            </div>
        </div>
        <div class="page-content container-fluid">
            <div class="widget">
                <div class="widget-body">
                    <div class="row">
                        <input id="id_transporte" name="id_transporte" hidden value="<?php echo $id_transporte ?>">
                        <div class="col-sm-4">
                            <address>
							<input id="id_transporte" type="hidden" value="<?php echo $id_transporte ?>">
								<strong>Id </strong><?php echo $id_transporte ?><br>
                                <strong>Fecha </strong><?php echo $fecha ?><br>
                                <strong>Usuario </strong><?php echo $usuario ?><br>
                                <strong>Estado </strong>
								<?php 
									if ($estado == 0){ 
										echo '<span class="label label-warning">Pendiente</span>';
										?>
											<button class="btn btn-raised btn-black pull-right finalizar">Finalizar Transporte
											</button>
											<?php
									}
									else 
										if($estado == -1){
											echo '<span class="label label-default">Anulada</span>';
										}
										else
											echo '<span class="label label-success">Transportada</span>';
								
								?>
                                <br>
                            </address>
                        </div>
                    </div>
					
                    <div class="table-responsive">
					<h3 class="widget-title pull-left">Listado de Producto</h3>
                        <table id="dt_detalle"
						cellspacing="0" width="100%"
								class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
								<th>Id Transporte</th>
                                <th>Id Producto</th>
                                <th>Producto</th>
                                <th class="center">Inicio</th>
								<th class="center">Saldo</th>
								<th class="center">Devolución Reposición</th>
								<th class="center">Devolución Cambio</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
					
					<div class="table-responsive">
					<br>
					<h3 class="widget-title pull-left">Listado de Ingreso de Dinero por Cobros</h3>
                        <table id="dt_pago"
						cellspacing="0" width="100%"
								class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Fecha</th>
                                <th class="center">Venta</th>
								<th class="center">Total Bs</th>
                            </tr>
                            </thead>
                            <tbody>
							</tbody>
							<tfoot>
								<tr> 
									<th colspan="3" style="text-align:right">Total Bs:</th> 
									<th></th>
								</tr> 
							</tfoot>
                        </table>
                    </div>
					<div class="table-responsive">
					<br>
					<h3 class="widget-title pull-left">Listado de Ingreso de Dinero por Ventas</h3>
                        <table id="dt_venta"
						cellspacing="0" width="100%"
								class="table table-striped table-bordered table-condensed">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Fecha</th>
                                <th class="center">Venta</th>
								<th class="center">Total Bs</th>
                            </tr>
                            </thead>
                            <tbody>
							</tbody>
							<tfoot>
								<tr> 
									<th colspan="3" style="text-align:right">Total Bs:</th> 
									<th></th>
								</tr> 
							</tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>


</div>

<!-- jQuery-->
<script type="text/javascript" src="../../../public/plugins/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap JavaScript-->
<script type="text/javascript" src="../../../public/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Malihu Scrollbar-->
<script type="text/javascript"
        src="../../../public/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Animo.js-->
<script type="text/javascript" src="../../../public/plugins/animo.js/animo.min.js"></script>
<!-- Bootstrap Progressbar-->
<script type="text/javascript"
        src="../../../public/plugins/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- Toastr-->
<script type="text/javascript" src="../../../public/plugins/toastr/toastr.min.js"></script>
<!-- MomentJS-->
<script type="text/javascript" src="../../../public/plugins/moment/min/moment.min.js"></script>
<script src="../../../public/plugins/moment/locale/es.js" type="text/javascript"></script>

<!-- Bootstrap Datetime Picker-->
<script type="text/javascript"
        src="../../../public/plugins/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript" src="../../../public/plugins/input-mask/jquery.inputmask.js"></script>
<script type="text/javascript" src="../../../public/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<!-- DataTables-->
<script type="text/javascript" src="../../../public/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-buttons/js/buttons.print.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-colreorder/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>

<!-- jQuery Validation-->
<script type="text/javascript" src="../../../public/plugins/jquery-validation/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/jquery-validation/src/localization/messages_es.js"></script>

<script type="text/javascript" src="../../../public/build/js/app.js"></script>
<script type="text/javascript" src="../../../public/js/helpers.js"></script>
<script type="text/javascript" src="../../../public/js/transporte_show.js"></script>

</body>
</html>


