<?php

session_start();
if (!isset($_SESSION['id_usuario'])) {
    header("Location: ../login.php");
}
require '../../datos/DTienda.php';
require '../../datos/DUsuario.php';

$usuario =new DUsuario();
$tienda = new DTienda();

/*$id_venta = $_GET['Id'];
$fecha = $_GET['F'];
$total = $_GET['To'];
$nombre_usuario = $_GET['U'];
$nombre_tienda = $_GET['Ti'];
$estado = $_GET['E'];*/

$FechaI = $_GET['FechaI'];
$FechaF = $_GET['FechaF'];
$Tienda = $_GET['Tienda'];
$Usuario = $_GET['Usuario'];
$Estado = $_GET['Estado'];



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bread King</title>
    <!-- PACE-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/PACE/themes/blue/pace-theme-flash.css">
    <script type="text/javascript" src="../../../public/plugins/PACE/pace.min.js"></script>
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/bootstrap/dist/css/bootstrap.min.css">
    <!-- Fonts-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/themify-icons/themify-icons.css">
    <!-- Malihu Scrollbar-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css">
    <!-- Animo.js-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/animo.js/animate-animo.min.css">

    <!-- Bootstrap Progressbar-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css">
    <!-- Toastr-->
    <link rel="stylesheet" type="text/css" href="../../../public/plugins/toastr/toastr.min.css">
    <!-- Primary Style-->
    <link rel="stylesheet" type="text/css" href="../../../public/build/css/second-layout.css">
    <!-- Bootstrap DateTimePicker-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css">
    <!-- DataTables-->
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-buttons-bs/css/buttons.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-colreorder-bs/css/colReorder.bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
          href="../../../public/plugins/datatables.net-responsive-bs/css/responsive.bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="../../../public/build/css/style.css">
</head>
<body data-sidebar-color="sidebar-light" class="sidebar-light">
<!-- Header start-->
<header>
    <a href="index.php" class="brand pull-left">
        <h2>BREAD KING</h2></a><a href="javascript:;" role="button"
                                  class="hamburger-menu pull-left visible-xs"><span></span></a>

    <ul class="notification-bar list-inline pull-right">
        <li class="visible-xs"><a href="javascript:;" role="button" class="header-icon search-bar-toggle"><i
                        class="ti-search"></i></a></li>
        <li class="visible-lg"><a href="javascript:;" role="button" class="header-icon fullscreen-toggle"><i
                        class="ti-fullscreen"></i></a></li>

        <li><a href="../logout.php" role="button" class="header-icon"><i class="ti-power-off"></i></a></li>
    </ul>
</header>
<!-- Header end-->
<div class="main-container">
    <!-- Main Sidebar start-->
    <aside data-mcs-theme="minimal-dark" class="main-sidebar mCustomScrollbar">
        <div class="user">

            <h4 class="fs-14 text-muted mt-15 mb-5 fw-300"><?php echo $_SESSION['nombre'] ?></h4>
            <p class="fs-13 mb-0 text-muted"></p>
        </div>
        <?php include("../menu.html"); ?>
    </aside>
    <!-- Main Sidebar end-->
    <div class="page-container">
        <div class="page-header clearfix">
            <div class="pull-left">
                <h4 class="mt-0 mb-5">Ventas<?php 
                
                if($Estado==null || $Estado=="")
                {
                    
                    $Estado = -1;
                }
                 ?></h4>
                <ol class="breadcrumb mb-0">
                    <li><a href="#">reporte_venta</a></li>
                    <li><a href="#">reporte_venta</a></li>
                    <li><a href="index_reporte_venta.php">Reporte de Ventas</a></li>
                    <li class="active">Reporte de Ventas</li>
                </ol>
            </div>
        </div>
        <div class="page-content container-fluid">
            <div class="widget">
                <div class="widget-body">
                    <form id="form-compra" method="post" novalidate="novalidate">
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="fecha">Fecha Inicio</label>
									
                                    <div data-format="dd/mm/yyyy" class="input-group">
                                        <input id="fecha_inicio" type="text" name="fecha_inicio"
                                               data-rule-required="true"
											   value="<?php 
											   if($FechaI==null){
												   echo date("d/m/Y"); 
											   }else
											   {
												   echo $FechaI;
											   }
											   ?>"
                                               class="form-control"><span class="input-group-addon"><i
                                                    class="ti-calendar"></i></span>
                                    </div>
                                </div>
                            </div>
							<div class="col-md-2">
                                <div class="form-group">
                                    <label for="fecha">Fecha Fin</label>
                                    <div data-format="dd/mm/yyyy" class="input-group">
                                        <input id="fecha_fin" type="text" name="fecha_fin"
                                               data-rule-required="true"
											   value="<?php 
											   if($FechaF==null){
												   echo date("d/m/Y"); 
											   }else
											   {
												   echo $FechaF;
											   }
											   ?>"
                                               class="form-control"><span class="input-group-addon"><i
                                                    class="ti-calendar"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tienda">Tienda</label>
                                    <select id="tienda" name="tienda" data-rule-required="true"
                                            class="form-control">
                                        <option value="0">Todas</option>
                                        <?php
                                        $lista = $tienda->getTiendas_Reporte_Venta();
                                        while ($row = $lista->fetch_array()):;?> 
										<?php
											if($row[0]==$Tienda)
											{
												?>
												<option selected='selected' value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option>
												<?php
											}else
											{	
												?>
												<option value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option>
												<?php
											}											
										endwhile; 
											
										?>
                                    </select>
                                </div>
                            </div>
							<div class="col-md-2">
                                <div class="form-group">
                                    <label for="usuario">Usuario</label>
                                    <select id="usuario" name="usuario" data-rule-required="true"
                                            class="form-control">
                                        <option value="0">Todos</option>
                                        <?php
                                        $lista = $usuario->getUsuarios_Reporte_Venta();
                                        while ($row = $lista->fetch_array()):;?> 
										<?php
											if($row[0]==$Usuario)
											{
												?>
												<option selected='selected' value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option>
												<?php
											}else
											{	
												?>
												<option value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option>
												<?php
											}											
										endwhile; 
											
										?>
                                    </select>
                                </div>
                            </div>
							<div class="col-md-2">
                                <div class="form-group">
                                    <label for="estado">Estado</label>
                                    <select id="estado" name="estado" data-rule-required="true"
                                            class="form-control">
                                        <option 
										<?php 
                                            
											if($Estado==-1){ ?>
												selected='selected'
												<?php
											}
										?>
										value="-1">Todas</option>
										<option 
										<?php 
											if($Estado==0){ ?>
												selected='selected'
												<?php
											}
										?>
										value="0">Por Pagar</option>
										<option 
										<?php 
											if($Estado==1){ ?>
												selected='selected'
												<?php
											}
										?>
										value="1">Cancelada</option>
										<option 
										<?php 
											if($Estado==2){ ?>
												selected='selected'
												<?php
											}
										?>
										value="2">Anuladas</option>
                                    </select>
                                </div>
                            </div>

                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <div class="row pull-center">
                                    <button type="button"
                                            class="btn btn-raised btn-black pull-center consultar">Consultar
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <table id="dt_ventas" cellspacing="0" width="100%"
								class="table table-striped table-bordered table-condensed">
                                    <thead>
                                    <tr>
                                        <th class="text-center">Acciones</th>
										<th>Id</th>
                                        <th>Tienda</th>
                                        <th>Usuario</th>
                                        <th>Fecha</th>
                                        <th>Estado</th>
										<th>Total</th>
                                        <th>Factura</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    </tbody>
									<tfoot>
										<tr> 
											<th colspan="6" style="text-align:right">Total:</th> 
											<th></th>
										</tr> 
									</tfoot>
                                </table>
                            </div>
                        </div>
                    </form>
                    <br>

                </div>
            </div>
        </div>


    </div>


</div>

<!-- jQuery-->
<script type="text/javascript" src="../../../public/plugins/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap JavaScript-->
<script type="text/javascript" src="../../../public/plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Malihu Scrollbar-->
<script type="text/javascript"
        src="../../../public/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
<!-- Animo.js-->
<script type="text/javascript" src="../../../public/plugins/animo.js/animo.min.js"></script>
<!-- Bootstrap Progressbar-->
<script type="text/javascript"
        src="../../../public/plugins/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- Toastr-->
<script type="text/javascript" src="../../../public/plugins/toastr/toastr.min.js"></script>
<!-- MomentJS-->
<script type="text/javascript" src="../../../public/plugins/moment/min/moment.min.js"></script>
<script src="../../../public/plugins/moment/locale/es.js" type="text/javascript"></script>

<!-- Bootstrap Datetime Picker-->
<script type="text/javascript"
        src="../../../public/plugins/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript" src="../../../public/plugins/input-mask/jquery.inputmask.js"></script>
<script type="text/javascript" src="../../../public/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<!-- DataTables-->
<script type="text/javascript" src="../../../public/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-buttons/js/buttons.print.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-colreorder/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script type="text/javascript"
        src="../../../public/plugins/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>

<!-- jQuery Validation-->
<script type="text/javascript" src="../../../public/plugins/jquery-validation/dist/jquery.validate.min.js"></script>
<script type="text/javascript" src="../../../public/plugins/jquery-validation/src/localization/messages_es.js"></script>

<script type="text/javascript" src="../../../public/build/js/app.js"></script>
<script type="text/javascript" src="../../../public/js/helpers.js"></script>

<script type="text/javascript" src="../../../public/js/reporte_venta.js"></script>

</body>
</html>


