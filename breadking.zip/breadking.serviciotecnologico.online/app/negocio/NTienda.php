<?php
//require '/../datos/tienda.php';
//prueba2
require $_SERVER['DOCUMENT_ROOT'].'/app/datos/DTienda.php';
if (isset($_REQUEST['funcion'])) {
    $tienda = new NTienda();
    switch ($_REQUEST['funcion']) {
        case "insertar":
			$Id_Grupo_Tienda = $_POST['Id_Grupo_Tienda'];
            $nombre = $_POST['nombre'];
            $razon_social = $_POST['razon_social'];
            $nit = $_POST['nit'];
            $direccion = $_POST['direccion'];
            $coordenadas = $_POST['coordenadas'];
            $telefono = $_POST['telefono'];
            $contacto = $_POST['contacto'];
            $tienda->insertarTienda($Id_Grupo_Tienda,$nombre,$razon_social, $nit, $direccion, $coordenadas, $telefono, $contacto);
            break;
        case "modificar":
            $id_tienda = $_POST['id_tienda'];
			$Id_Grupo_Tienda = $_POST['Id_Grupo_Tienda'];
            $nombre = $_POST['nombre'];
			$razon_social = $_POST['razon_social'];
            $nit = $_POST['nit'];
            $direccion = $_POST['direccion'];
            $coordenadas = $_POST['coordenadas'];
            $telefono = $_POST['telefono'];
            $contacto = $_POST['contacto'];
			$Frecuencia_Visita = $_POST['Frecuencia_Visita'];
            $tienda->modificarTienda($id_tienda,$Id_Grupo_Tienda, $nombre,$razon_social, $nit, $direccion, $coordenadas, $telefono, $contacto,$Frecuencia_Visita);
            break;
        case "habilitar":
            $id_tienda = $_POST['id_tienda'];
            $tienda->habilitarTienda($id_tienda);
            break;
        case "deshabilitar":
            $id_tienda = $_POST['id_tienda'];
            $tienda->deshabilitarTienda($id_tienda);
            break;
        case "listado":
            $tienda->listadoTiendas();
            break;
    }
}

class NTienda
{
    public function insertarTienda($Id_Grupo_Tienda,$nombre, $razon_social, $nit, $direccion, $coordenadas, $telefono, $contacto)
    {
        $tienda = new DTienda();
		$tienda->setId_Grupo_Tienda($Id_Grupo_Tienda);
        $tienda->setNombre($nombre);
       $tienda->setRazon_Social($razon_social);
        $tienda->setNIT($nit);
        $tienda->setDireccion($direccion);
        $tienda->setCoordenadas($coordenadas);
        $tienda->setTelefono($telefono);
        $tienda->setContacto($contacto);
        $result = $tienda->insertarTienda();
        if ($result) {
            echo 'Tienda guardada satisfactoriamente';
        } else {
            echo 'Error al guardar los datos ' + $result;
        }
    }

    public function modificarTienda($id_tienda,$Id_Grupo_Tienda, $nombre, $razon_social, $nit, $direccion, $coordenadas, $telefono, $contacto,$Frecuencia_Visita)
    {
        $tienda = new DTienda();
        $tienda->setId($id_tienda);
		$tienda->setId_Grupo_Tienda($Id_Grupo_Tienda);
        $tienda->setNombre($nombre);
        $tienda->setNIT($nit);
		$tienda->setRazon_Social($razon_social);
        $tienda->setDireccion($direccion);
        $tienda->setCoordenadas($coordenadas);
        $tienda->setTelefono($telefono);
        $tienda->setContacto($contacto); 
		$tienda->setFrecuencia_Visita($Frecuencia_Visita);
        $result = $tienda->modificarTienda();
        if ($result) {
            echo 'Tienda modificada satisfactoriamente';
        } else {
            echo 'Error al guardar los datos ' + $result;
        }
    }

    public function habilitarTienda($id_tienda)
    {
        $tienda = new DTienda();
        $tienda->setId($id_tienda);
        $result = $tienda->habilitarTienda();
        if ($result) {
            echo 'Tienda habilitada satisfactoriamente';
        } else {
            echo 'Error ' + $result;
        }
    }

    public function deshabilitarTienda($id_tienda)
    {
        $tienda = new DTienda();
        $tienda->setId($id_tienda);
        $result = $tienda->deshabilitarTienda();
        if ($result) {
            echo 'Tienda deshabilitada satisfactoriamente';
        } else {
            echo 'Error ' + $result;
        }
    }


    public function listadoTiendas()
    {
        $tienda = new DTienda();
        $lista = $tienda->listadoTiendas();
        echo $lista;
    }
}