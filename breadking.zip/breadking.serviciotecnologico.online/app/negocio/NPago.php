<?php
require $_SERVER['DOCUMENT_ROOT'] . '/app/datos/DPago.php';

if (isset($_REQUEST['funcion'])) {
    $pago = new NPago();
    switch ($_REQUEST['funcion']) {
        case "listadoPagos":
			$Id_Transportar = $_REQUEST['id_transporte'];
            $pago->listadoPagos($Id_Transportar);
            break;
    }
}

class NPago
{
    public function listadoPagos($Id_Transportar)
    {
        $pago = new DPago();
        $lista = $pago->listadoPagos($Id_Transportar);
        echo $lista;
		//'{"data":[{"Id":"3","Fecha":"19-08-2021","Venta":"188","Total":"40"}]}';
    }
}

