<?php

class Conexion
{

    private $host = 'localhost';
    private $user = 'user_bd_breadking';
    private $password = 'uw22&m5Z';
    private $database = 'bd_breadking';

//    private $host = 'localhost';
//    private $user = 'root';
//    private $password = '';
//    private $database = 'breadking';
//
    private $link;
    private $statement;
    static $_instance;

    private function __construct()
    {
        $this->conectar();
    }

    private function __clone()
    {

    }

    public static function getInstance()
    {
        if (!(self::$_instance instanceof self)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function conectar()
    {
        $this->link = mysql_connect($this->host, $this->user, $this->password);
        mysql_select_db($this->database, $this->link);
        mysql_set_charset('utf8', $this->link);
    }

	public function comenzar_transaccion()
	{
		mysql_query("START TRANSACTION");
	}
	
    public function ejecutar($query)
    {
		mysql_freeresult();
        $this->statement = mysql_query($query, $this->link);
		if (!$this->statement)
		{
			echo("Error description: " . mysql_errno() . ": " . mysql_error($this->link));
		}
        return $this->statement;
    }
	
	public function guardar_transaccion()
	{
		mysql_query("COMMIT");
	}
	
	public function cancelar_transaccion()
	{
		mysql_query("ROLLBACK");
	}
	
    public function close()
    {
        mysql_close($this->link);
    }

    public function last_id()
    {
        return mysql_insert_id();
    }

}
