<?php
//include_once 'conexion.php';
include_once 'ConexionMySqli.php';

class DPago
{
    //private $tabla = 'Pago';
    private $Id;
	private $Id_Venta;
    private $Id_Usuario;
	private $Id_Transportar;
    private $Fecha;
    private $Total;
    

    function listadoPagos($Id_Transportar)
    {
        try {
            $sql = "SELECT Pago.Id,Pago.fecha AS Fecha,Pago.Id_Venta as Venta, Pago.total as Total
FROM Pago WHERE Pago.Id_Transportar=".$Id_Transportar;
			
			$cone =  new Database();
			$tabla = $cone->get_json_rows($sql);
			return '{"data":[' . $tabla . ']}';
        } catch (Exception $exc) {
            echo $exc->getTraceAsString();
        }
    }
	
	

    public function formatDate($date)
    {
        $date_p = explode('/', $date);
        $date_u = array($date_p[2], $date_p[1], $date_p[0]);
        $date_f = implode('-', $date_u);
        return $date_f;
    }

    public function formatDatePicker($date)
    {
        $date_p = explode('-', $date);
        $date_u = array($date_p[2], $date_p[1], $date_p[0]);
        $date_f = implode('/', $date_u);
        return $date_f;
    }


}