$(document).ready(function () {
    
	var id_venta = $('#id_venta').val();
	$('#dt_detalle').DataTable({
		"paging": false,
        "ordering": false,
        "info": false,
        "searching": false,
		"ajax": {
            "url": "../../negocio/NDetalle_Venta.php?funcion=detalle",
			"type": "GET",
            "data": {id_venta: id_venta},
        },
        
		"columns": [
            {"data": "Id"},
            {"data": "Producto"},
			{"data": "Precio"},
            {"data": "Cantidad"},
            {"data": "Total"},
        ],
        "language": {
            "url": "../../../public/plugins/datatables.net/Spanish.json"
        },
        "columnDefs": [
            {
                "targets": [0],
                "visible": false
            }, {
                "targets": 3,
                "className": "text-center"
            }, {
                "targets": [2, 4],
                "className": "text-right"
            }
        ],
    });
});