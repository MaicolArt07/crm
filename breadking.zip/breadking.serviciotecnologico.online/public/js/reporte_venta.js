$(document).ready(function () {
	ingreso = false;
    $('.consultar').click(function () {
		//ingreso =  true;
		var FechaI = $('#fecha_inicio').val();
		//alert 'Consultar:'.FechaI;
		var FechaF = $('#fecha_fin').val();
		var Tienda = $('#tienda').val();
		var Usuario = $('#usuario').val();
		var Estado = $('#estado').val();
		
		location.href = "index_reporte_venta.php?FechaI=" + FechaI 
		+ "&FechaF=" + FechaF
		+ "&Usuario=" + Usuario
		+ "&Tienda=" + Tienda
		+ "&Estado=" + Estado;
		
		
    });
	if(ingreso==false){
		var FechaI = $('#fecha_inicio').val();
		var FechaF = $('#fecha_fin').val();
		var FechaI = FechaI.split("/").reverse().join("/");
		var FechaF = FechaF.split("/").reverse().join("/");
		var Tienda = $('#tienda').val();
		var Usuario = $('#usuario').val();
		var Estado = $('#estado').val();
		$("#dt_ventas").DataTable({
			"ajax": {
				type: "POST",
				url: "../../negocio/NVenta.php?funcion=Ventas_Reporte_Venta",
				data: {
					FechaI: FechaI,
					FechaF: FechaF,
					Tienda: Tienda,
					Usuario: Usuario,
					Estado: Estado
				}
			},
			"columns": [
				{
					"defaultContent": "<div class='btn-group btn-group-sm'>" +
					"<a class='btn btn-outline btn-primary show'><i class='ti-eye'></i></a>"  +
					"</div>"
				},
				{"data": "Id"},
				{"data": "Tienda"},
				{"data": "Usuario"},
				{"data": "Fecha"},
				{"data": "Estado"},
				{"data": "Total"},
				{"data": "Numero_Factura"},

			],
			"pageLength": 10,
			"language": {
				"url": "../../../public/plugins/datatables.net/Spanish.json"
			},
			"columnDefs": [
				{
					"targets": 0,
					"visible": true,
					"className": "text-center",
					 "width": "100px"
				}, 
				{
					"targets": 6,
					"className": "text-center",
					"orderable": false
				}, 
				{
					"targets": 5,
					"className": "text-center",
					"orderable": true
				},
				{type: 'date-eu', targets: 1},
				{type: 'date-eu', targets: 0}
			],
			"responsive": true,
			"fnRowCallback": function (nRow, aData, iDisplayIndex) {
				if (aData['Estado'] == 0) {
					$('td:eq(5)', nRow).html('<span class="label label-warning">Por Pagar</span>');

				} else {
					if (aData['Estado'] == 1) {
						$('td:eq(5)', nRow).html('<span class="label label-success">Cancelada</span>');
					}else{
						$('td:eq(5)', nRow).html('<span class="label label-default">Anulada</span>');
					}
				}
				
			},
			"order": [[4, "desc"]],
			"footerCallback": function ( row, data, start, end, display ) {
				var api = this.api(), data;
	 
				// Remove the formatting to get integer data for summation
				var intVal = function ( i ) {
					return typeof i === 'string' ?
						i.replace(/[\$,]/g, '')*1 :
						typeof i === 'number' ?
							i : 0;
				};
	 
				// Total over all pages
				total = api
					.column( 6 )
					.data()
					.reduce( function (a, b) {
						return intVal(a) + intVal(b);
					}, 0 );
	 
				// Total over this page
				pageTotal = api
					.column( 6, { page: 'current'} )
					.data()
					.reduce( function (a, b) {
						return intVal(a) + intVal(b);
					}, 0 );
	 
				// Update footer
				$( api.column( 6 ).footer() ).html(
					''+pageTotal +' ( '+ total +' total)'
				);
			}
		});
	}
	

    var table = $('#dt_ventas').DataTable();
	
	$('#dt_ventas tbody').on('click', '.show', function () {
		var data = table.row($(this).parents('tr')).data();
		
        location.href = "show_reporte_ventas.php?Id=" + data.Id + "&F=" + data.Fecha + "&To=" + data.Total + "&U=" + data.Usuario+ "&Ti=" + data.Tienda+ "&E=" + data.Estado;
    });
	
	
    $('#fecha_inicio').setDateTime();
    $('#fecha_fin').setDateTime();
	
	
});
