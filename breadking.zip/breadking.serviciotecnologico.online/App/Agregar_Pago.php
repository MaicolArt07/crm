
<?php
  
   require('datos/gestor.php');
   require('CodigoControl.php');
   require('Sin/ControlCode.php');
    //$JSON_venta = $_REQUEST["JSON_venta"];
	//$obj = json_decode($JSON_venta, true);
	
	$Id_Venta = $_REQUEST['Id_Venta'];
	$Id_Usuario = $_REQUEST['Id_Usuario'];
	
	$gestor= new Gestor();
	
	$Agregar_Pago= $gestor->Agregar_Pago($Id_Venta,$Id_Usuario);
	echo ("GUARDADO OK ".$Agregar_Pago);
    
?>