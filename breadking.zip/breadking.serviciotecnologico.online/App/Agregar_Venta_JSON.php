
<?php
  
   require('datos/gestor.php');
   require('CodigoControl.php');
   require('Sin/ControlCode.php');
    $JSON_venta = $_REQUEST["JSON_venta"];
	$obj = json_decode($JSON_venta, true);
	
	$Id_Tienda = $obj['Id_Tienda'];
	$Id_Usuario = $obj['Id_Usuario'];
	$Total = $obj['Total'];
	$Facturado = $obj['Facturado'];
	
	$gestor= new Gestor();
	$gestor->Abrir_Conexion();
	//$gestor->Habilitar_Commit();
	
	$Agregar_Venta= $gestor->Agregar_Venta($Id_Tienda,$Id_Usuario,$Total);
	
	$obj_Agregar_Venta = json_decode($Agregar_Venta, true);
	//var_dump($obj_Agregar_Venta);
	$Id_Venta = $obj_Agregar_Venta['Id_Venta'];
	if($Id_Venta > 0){
		//echo ' Respuesta al Agregar_Venta:'.$Id_Venta;
	}else{
		$gestor->rollback();
		$data['Respuesta'] = 'ERROR: Agregar_Venta_JSON.php: aplicacion finalizada al Agregar_Venta';
		exit(json_encode($data));
	}
	$Fecha_Hora = $obj_Agregar_Venta['Fecha_hora'];
	$fecha = $obj_Agregar_Venta['Fecha_hora'];//10/08/2010/2020-07-13
	$parts = explode(" ",$fecha);
	$fecha = $parts[0];
	$fecha = str_replace('-','',$fecha);
	$cont =0;
	foreach ($obj['lista_detalle_venta'] as $detalle_venta) {
		//echo "\$a[$i] => $v.\n";
		$Producto = $detalle_venta['Producto'];
		$Cantidad = $detalle_venta['Cantidad'];
		$Precio = $detalle_venta['Precio'];
		
		$Agregar_Detalle_Venta = $gestor->Agregar_Detalle_Venta($Id_Venta,$Producto,$Cantidad,$Precio);
		$obj_Agregar_Detalle_Venta = json_decode($Agregar_Detalle_Venta, true); 
		if($obj_Agregar_Detalle_Venta['Id'] > 0){
			//echo ' Respuesta al Agregar_Detalle_Venta:'.$obj_Agregar_Detalle_Venta['Id'];
		}else{
			$gestor->rollback();
			$data['Respuesta'] = 'ERROR: Agregar_Venta_JSON.php: aplicacion finalizada al Agregar_Detalle_Venta';
			exit(json_encode($data));
		}
		$cont++;
	}
	
	if($Facturado==1){
		$Agregar_Factura = $gestor->Agregar_Factura($Id_Venta,$Id_Tienda);
		$obj_Agregar_Factura = json_decode($Agregar_Factura, true);
		$Id_Factura = $obj_Agregar_Factura["Id_Factura"];
		if($Id_Factura > 0){
		//echo ' Respuesta al Agregar_Factura:'.$Id_Factura;
		}else{
			$gestor->rollback();
			$data['Respuesta'] = 'ERROR: Agregar_Venta_JSON.php: aplicacion finalizada al Agregar_Factura';
			exit(json_encode($data));
		}
		
		//var_dump($obj_Agregar_Factura);
		$Razon_Social=$obj_Agregar_Factura["Razon_Social"];
		$autorizacion=$obj_Agregar_Factura["Autorizacion"];
		$Fecha_Limite_Emision = $obj_Agregar_Factura["Fecha_Limite_Emision"];
		$nrofactura=$obj_Agregar_Factura["Numero_Factura"];
		$nitci=$obj_Agregar_Factura["NIT"];
		$fecha = $fecha;
		$monto=$Total;
		$llave=$obj_Agregar_Factura['llave_dosificacion'];
		
		$controlCode = new ControlCode();
		if($nitci==""){
			$nitci="0";
		}
		$Codigo_Control = $controlCode->generate($autorizacion, $nrofactura, $nitci, $fecha, $monto, $llave);
		if($Codigo_Control!=null){
			//echo " Codigo_Control:".$Codigo_Control;
		}else{
			$gestor->rollback();
			$data['Respuesta'] = 'ERROR: Agregar_Venta_JSON.php: aplicacion finalizada al controlCode->generate';
			exit(json_encode($data));
		}
		
		
		
		$Colocar_Codigo_Control_Factura = $gestor->Colocar_Codigo_Control_Factura($Id_Factura,$Codigo_Control);
		$obj_Colocar_Codigo_Control_Factura = json_decode($Colocar_Codigo_Control_Factura, true);
		$Id_Factura = $obj_Colocar_Codigo_Control_Factura["Id"];
		if($Id_Factura > 0){
			//echo ' Respuesta al Colocar_Codigo_Control_Factura:'.$Id_Factura;
		}else{
			$gestor->rollback();
			$data['Respuesta'] = 'ERROR: Agregar_Venta_JSON.php: aplicacion finalizada al Colocar_Codigo_Control_Factura';
			exit(json_encode($data));
		}
		$data['Id_Venta'] = $Id_Venta;
		$data['Fecha']=$Fecha_Hora;
		$data['Id_Factura'] = $Id_Factura;
		$data['Numero_Factura'] = $nrofactura;
		$data['NIT'] = $nitci;
		$data['Razon_Social'] = $Razon_Social;
		$data['Autorizacion'] = $autorizacion;
		$data['Fecha_Limite_Emision'] = $Fecha_Limite_Emision;
		$data['Codigo_Control'] = $Codigo_Control;
		$data['Respuesta'] = 'GUARDADO OK';
		echo json_encode($data);
	}else{
		$data['Id_Venta'] = $Id_Venta;
		$data['Fecha']=$Fecha_Hora;
		$data['Id_Factura'] = -1;
		$data['Codigo_Control'] = '';
		$data['Respuesta'] = 'GUARDADO OK';
		echo json_encode($data);
	}
?>