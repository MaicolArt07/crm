<meta charset=”UTF-8″>
<?php
  
   require('datos/gestor.php');
     
    $Id_Venta = $_REQUEST["Id_Venta"];
    $Producto = $_REQUEST["Producto"];
	$Cantidad = $_REQUEST["Cantidad"];
	$Precio = $_REQUEST["Precio"];

    $gestor= new Gestor();
    $Agregar_Detalle_Venta= $gestor->Agregar_Detalle_Venta($Id_Venta,$Producto,$Cantidad,$Precio);
	
    echo ($Agregar_Detalle_Venta);
?>