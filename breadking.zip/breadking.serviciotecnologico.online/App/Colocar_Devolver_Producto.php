﻿<meta charset=”UTF-8″>
<?php
  
   require('datos/gestor.php');
     
    $Tienda = $_REQUEST["Tienda"];
    $Id_Usuario = $_REQUEST["Id_Usuario"];
    $Producto = $_REQUEST["Producto"];
    $Cantidad = $_REQUEST["Cantidad"];

    $gestor=Gestor::getInstance();
    $Colocar_Devolver_Producto= $gestor->Colocar_Devolver_Producto($Tienda,$Id_Usuario,$Producto,$Cantidad,$Accion);
    

    echo ($Colocar_Devolver_Producto);
?>