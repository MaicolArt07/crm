<meta charset=”UTF-8″>
<?php
  
   require('datos/gestor.php');
    $Id_Factura = $_REQUEST["Id_Factura"];
    $Codigo_Control = $_REQUEST["Codigo_Control"];
    $gestor= new Gestor();
    $Colocar_Codigo_Control_Factura= $gestor->Colocar_Codigo_Control_Factura($Id_Factura,$Codigo_Control);
    echo ($Colocar_Codigo_Control_Factura);
?>