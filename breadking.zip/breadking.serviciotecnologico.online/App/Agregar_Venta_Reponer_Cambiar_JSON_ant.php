<?php
  
   require('datos/gestor.php');
   require('CodigoControl.php');
   require('Sin/ControlCode.php');
    $JSON_venta = $_REQUEST["JSON_venta"];
	$obj = json_decode($JSON_venta, true);
	$Id_Tienda = $obj['Id_Tienda'];
	$Id_Usuario = $obj['Id_Usuario'];
	$Id_Venta = 0;
	
	$gestor= new Gestor();
	$gestor->Abrir_Conexion();
	$gestor->DesHabilitar_AutoCommit();
	
	if(count($obj['lista_detalle_venta'])>0){
		$SubTotal = $obj['SubTotal'];
		$Descuento = $obj['Descuento'];
		$Total = $obj['Total'];
		$Facturado = $obj['Facturado'];
		$Estado = $obj['Estado'];
		
		
		
		$Agregar_Venta= $gestor->Agregar_Venta_V2($Id_Tienda,$Id_Usuario,$SubTotal,$Descuento,$Total,$Estado);
		
		$obj_Agregar_Venta = json_decode($Agregar_Venta, true);
		//var_dump($obj_Agregar_Venta);
		$Id_Venta = $obj_Agregar_Venta['Id_Venta'];
		if($Id_Venta > 0){
			//echo ' Respuesta al Agregar_Venta:'.$Id_Venta;
		}else{
			$gestor->rollback();
			$data['Respuesta'] = 'ERROR-> Agregar_Venta_JSON.php: aplicacion finalizada al Agregar_Venta';
			exit(json_encode($data));
		}
		$Fecha_Hora = $obj_Agregar_Venta['Fecha_hora'];
		$fecha = $obj_Agregar_Venta['Fecha_hora'];//10/08/2010/2020-07-13
		$parts = explode(" ",$fecha);
		$fecha = $parts[0];
		$fecha = str_replace('-','',$fecha);
		$cont =0;
		foreach ($obj['lista_detalle_venta'] as $detalle_venta) {
			//echo "\$a[$i] => $v.\n";
			$Producto = $detalle_venta['Producto'];
			$Cantidad = $detalle_venta['Cantidad'];
			$Precio = $detalle_venta['Precio'];
			$Descuento = $detalle_venta['Descuento'];
			$Precio_Final = $detalle_venta['Precio_Final'];
			$Total = $detalle_venta['Total'];
			$Agregar_Detalle_Venta = $gestor->Agregar_Detalle_Venta($Id_Venta,$Producto,$Cantidad,$Precio,$Descuento,$Precio_Final,$Total,$Id_Usuario);
			if($Agregar_Detalle_Venta==-1){
				$gestor->rollback();
				$data['Respuesta_Venta'] = 'No se pudo Guardar, error al registrar el detalle de Venta del Producto '.$Producto.' con cantidad '.$Cantidad;
				exit(json_encode($data));
			}
			$cont++;
		}
		
		if($Facturado==1){
			$Agregar_Factura = $gestor->Agregar_Factura($Id_Venta,$Id_Tienda);
			$obj_Agregar_Factura = json_decode($Agregar_Factura, true);
			$Id_Factura = $obj_Agregar_Factura["Id_Factura"];
			if($Id_Factura > 0){
			//echo ' Respuesta al Agregar_Factura:'.$Id_Factura;
			}else{
				$gestor->rollback();
				$data['Respuesta_Venta'] = 'ERROR-> Agregar_Venta_JSON.php: aplicacion finalizada al Agregar_Factura';
				exit(json_encode($data));
			}
			
			//var_dump($obj_Agregar_Factura);
			$Razon_Social=$obj_Agregar_Factura["Razon_Social"];
			$autorizacion=$obj_Agregar_Factura["Autorizacion"];
			$Fecha_Limite_Emision = $obj_Agregar_Factura["Fecha_Limite_Emision"];
			$nrofactura=$obj_Agregar_Factura["Numero_Factura"];
			$nitci=$obj_Agregar_Factura["NIT"];
			$fecha = $fecha;
			$monto=$Total;
			$llave=$obj_Agregar_Factura['llave_dosificacion'];
			
			$controlCode = new ControlCode();
			if($nitci==""){
				$nitci="0";
			}
			$Codigo_Control = $controlCode->generate($autorizacion, $nrofactura, $nitci, $fecha, $monto, $llave);
			if($Codigo_Control!=null){
				//echo " Codigo_Control:".$Codigo_Control;
			}else{
				$gestor->rollback();
				$data['Respuesta_Venta'] = 'ERROR-> Agregar_Venta_JSON.php: aplicacion finalizada al controlCode->generate';
				exit(json_encode($data));
			}
			
			$Colocar_Codigo_Control_Factura = $gestor->Colocar_Codigo_Control_Factura($Id_Factura,$Codigo_Control);
			$obj_Colocar_Codigo_Control_Factura = json_decode($Colocar_Codigo_Control_Factura, true);
			$Id_Factura = $obj_Colocar_Codigo_Control_Factura["Id"];
			if($Id_Factura > 0){
				//echo ' Respuesta al Colocar_Codigo_Control_Factura:'.$Id_Factura;
			}else{
				$gestor->rollback();
				$data['Respuesta_Venta'] = 'ERROR-> Agregar_Venta_JSON.php: aplicacion finalizada al Colocar_Codigo_Control_Factura';
				exit(json_encode($data));
			}
			$data['Id_Venta'] = $Id_Venta;
			$data['Fecha']=$Fecha_Hora;
			$data['Id_Factura'] = $Id_Factura;
			$data['Numero_Factura'] = $nrofactura;
			$data['NIT'] = $nitci;
			$data['Razon_Social'] = $Razon_Social;
			$data['Autorizacion'] = $autorizacion;
			$data['Fecha_Limite_Emision'] = $Fecha_Limite_Emision;
			$data['Codigo_Control'] = $Codigo_Control;
			$data['Respuesta_Venta'] = 'GUARDADO OK';
		}else{
			$data['Id_Venta'] = $Id_Venta;
			$data['Fecha']=$Fecha_Hora;
			$data['Id_Factura'] = -1;
			$data['Codigo_Control'] = '';
			$data['Respuesta_Venta'] = 'GUARDADO OK';
			
		}
	}else{
		$data['Id_Venta'] = -1;
		$data['Respuesta_Venta'] = 'NO APLICA GUARDADO';
	}
	
	$JSON_reponer = $_REQUEST["JSON_reponer"];
	$obj = json_decode($JSON_reponer, true);
	$Id_Reponer = 0;
	if(count($obj['lista_detalle_reponer'])>0){
		//echo 'datos para reponer';
		$Agregar_Reponer = $gestor->Agregar_Reponer($Id_Tienda,$Id_Usuario);
		$obj_Agregar_Reponer = json_decode($Agregar_Reponer, true);
		$Id_Reponer = $obj_Agregar_Reponer['Id_Reponer'];
		foreach ($obj['lista_detalle_reponer'] as $detalle_reponer) {
			//echo "\$a[$i] => $v.\n";
			$Producto = $detalle_reponer['Producto'];
			$Cantidad = $detalle_reponer['Cantidad'];
			$Agregar_Detalle_Reponer = $gestor->Agregar_Detalle_Reponer($Id_Reponer,$Producto,$Cantidad,$Id_Usuario);
			$obj_Agregar_Detalle_Reponer = json_decode($Agregar_Detalle_Reponer, true);
			$Id_Detalle_Reponer = $obj_Agregar_Detalle_Reponer['Id_Detalle_Reponer'];
			if($Id_Detalle_Reponer==-1){
				$gestor->rollback();
				$data['Respuesta_Reponer'] = 'ERROR-> No se pudo Guardar, error al registrar el detalle de Reponer del Producto '.$Producto.' con cantidad '.$Cantidad;
				exit(json_encode($data));
			}
			$cont++;
		}
		$data['Id_Reponer'] = $Id_Reponer;
	}else{
		$data['Id_Reponer'] = -1;
		$data['Respuesta_Reponer'] = 'NO APLICA GUARDADO';
	}
	
	$JSON_cambiar = $_REQUEST["JSON_cambiar"];
	$obj = json_decode($JSON_cambiar, true);
	$Id_Cambiar = 0;
	if(count($obj['lista_detalle_cambiar'])>0){
		$Agregar_Cambiar = $gestor->Agregar_Cambiar($Id_Tienda,$Id_Usuario);
		$obj_Agregar_Cambiar = json_decode($Agregar_Cambiar, true);
		$Id_Cambiar = $obj_Agregar_Cambiar['Id_Cambiar'];
		foreach ($obj['lista_detalle_cambiar'] as $detalle_cambiar) {
			//echo "\$a[$i] => $v.\n";
			$Producto_Colocar = $detalle_cambiar['Producto_Colocar'];
			$Producto_Retirar = $detalle_cambiar['Producto_Retirar'];
			$Cantidad = $detalle_cambiar['Cantidad'];
			$Agregar_Detalle_Cambiar = $gestor->Agregar_Detalle_Cambiar($Id_Cambiar,$Producto_Colocar,
			$Producto_Retirar,$Cantidad,$Id_Usuario);
			$obj_Agregar_Detalle_Cambiar = json_decode($Agregar_Detalle_Cambiar, true);
			$Id_Detalle_Cambiar = $obj_Agregar_Detalle_Cambiar['Id_Detalle_Cambiar'];
			if($Id_Detalle_Cambiar==-1){
				$gestor->rollback();
				$data['Respuesta_Cambiar'] = 'ERROR-> No se pudo Guardar, error al registrar el detalle de Cambiar del Producto Ingresar '.$Producto_Colocar.' y producto retirar '.$Producto_Retirar.' con cantidad '.$Cantidad;
				exit(json_encode($data));
			}
			$cont++;
		}
		$data['Id_Cambiar'] = $Id_Cambiar;
		//echo $Id_Cambiar;
	}else{
		$data['Id_Cambiar'] = -1;
		$data['Respuesta_Cambiar'] = 'NO APLICA GUARDADO';
	}
	
	if($Id_Venta>0 || $Id_Reponer>0 || $Id_Cambiar>0){
		 $Accion_Vender_Reponer_Cambiar = $gestor->Agregar_Accion_Vender_Reponer_Cambiar($Id_Venta,$Id_Reponer,$Id_Cambiar);
		 $obj_Accion_Vender_Reponer_Cambiar = json_decode($Accion_Vender_Reponer_Cambiar, true);
		 $Id_Accion_Vender_Reponer_Cambiar = $obj_Accion_Vender_Reponer_Cambiar['Id_Accion_Vender_Reponer_Cambiar'];
		 if($Id_Accion_Vender_Reponer_Cambiar==null){
				$gestor->rollback();
				$data['Respuesta'] = 'No se pudo Guardar, error al registrar la Accion con Id_Venta '.$Id_Venta.', Id_Reponer '.$Id_Reponer.' y Id_Cambiar '.$Id_Cambiar;
				exit(json_encode($data));
			}
		 $data['Id_Accion_Vender_Reponer_Cambiar'] = $Id_Accion_Vender_Reponer_Cambiar;
		 $data['Respuesta'] = 'GUARDADO OK';
	}
	
	$gestor->Commit();
	echo json_encode($data);
?>