<meta charset=”UTF-8″>
<?php
  
   require('datos/gestor.php');
    $Id_Venta = $_REQUEST["Id_Venta"];
    $Id_Tienda = $_REQUEST["Id_Tienda"];
    $gestor= new Gestor();
    $Agregar_Factura= $gestor->Agregar_Factura($Id_Venta,$Id_Tienda);
    echo ($Agregar_Factura);
?>