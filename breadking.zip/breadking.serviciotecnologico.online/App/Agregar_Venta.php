<meta charset=”UTF-8″>
<?php
  
   require('datos/gestor.php');
    $Id_Usuario = $_REQUEST["Id_Usuario"];
    $Id_Tienda = $_REQUEST["Id_Tienda"];
    $Total = $_REQUEST["Total"];
    $gestor= new Gestor();
    $Agregar_Venta= $gestor->Agregar_Venta($Id_Tienda,$Id_Usuario,$Total);
    echo ($Agregar_Venta);
?>