<?php


class EnviarFactura {
	function enviar(){   
        
        echo "hoal 2";
		$data = "{
\"Llave\":\"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJTVE9SRVNSTCIsImNvZGlnb1Npc3RlbWEiOiI3NzJEOUNCOEFENzgyMTNFRjk1MzYzNiIsIm5pdCI6Ikg0c0lBQUFBQUFBQUFETXhzREF5TXpRd01nUUFwX2dVUEFrQUFBQT0iLCJpZCI6MzAxNTgyMSwiZXhwIjoxNzE2NDIyNDAwLCJpYXQiOjE2ODQ5NDM1NTQsIm5pdERlbGVnYWRvIjo0MDgyNjEwMjEsInN1YnNpc3RlbWEiOiJTRkUifQ.pn1qTy4H_WhB5f8XYdBU4nk2YxNa0NMPQZuUafPRgkbjE6KBNE6dqQIqZd_6FKzqGf62hn4h3Osm0tlmzLkbpQ\",
\"Tipo_Pago\":\"Efectivo\",
\"Fecha\":\"2022-10-28\",
\"SubTotal\":15,
\"Descuento\":0,
\"Total\":15,
\"Numero_Factura\":590,
\"NIT\":\"6374102\",
\"Razon_Social\":\"SN\",
\"Correo\":\"edersantibanhez@gmail.com\",
\"Total_Literal\":\"Quince 00/100\",
\"Tipo_Documento\":5,
\"Complemento\":\"\",
\"Usuario\":\"Cajero 1\",
\"Lista_detalle_factura\":[{\"Id_Producto\":5,\"Nombre_Producto\":\"Producto 1\",\"Cantidad\":3,\"Total\":15}]
}";

$data ="{\"Llave\":\"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIzMTY4MTYwMjdBYSIsImNvZGlnb1Npc3RlbWEiOiI3NzU0MjEzNTNBNTlEQkNDOEEyNEM1RSIsIm5pdCI6Ikg0c0lBQUFBQUFBQUFETTJOTE13TkRNd01nY0FWNHp2b3drQUFBQT0iLCJpZCI6NTE5NzYzLCJleHAiOjE3MjM1OTM2MDAsImlhdCI6MTY5MjEzMTU1OSwibml0RGVsZWdhZG8iOjMxNjgxNjAyNywic3Vic2lzdGVtYSI6IlNGRSJ9.FPCX9XY1ZsqC_ZQF7A1x_pn6AwtFSstQvcHiA5zHF3ygx1ssggiwIQ7a6r3_nA6N4MD9C8wdQ8N6kf5_JA4F6Q\",\"Tipo_Pago\":\"Efectivo\",\"Fecha\":\"2022-10-28\",\"SubTotal\":54,\"Descuento\":0,\"Total\":54,\"Numero_Factura\":\"661\",\"NIT\":\"317118023\",\"Razon_Social\":\"SOPHIES
S.R.L.\",\"Correo\":\"eder.david@hotmail.es\",\"Total_Literal\":\"cincuenta y
cuatro\",\"Tipo_Documento\":5,\"Complemento\":\"\",\"Usuario\":\"Cajero\",\"Lista_detalle_factura\":[{\"Id_Producto\":\"21\",\"Nombre_Producto\":\"EMPANADA
INTEGRAL CON QUESO\",\"Cantidad\":2,\"Total\":16},{\"Id_Producto\":\"24\",\"Nombre_Producto\":\"CUNAPE
ABIZCOCHADO\",\"Cantidad\":3,\"Total\":30},{\"Id_Producto\":\"23\",\"Nombre_Producto\":\"GALLETA DE AVENA CON
ALMENDRA\",\"Cantidad\":1,\"Total\":8}]}";

//$data = $value;
$endpoint = "http://186.121.243.59:8080/WebSeriviceImpuestoTest_BreadKing/WBSincronizarImpuestoTest?wsdl";
$requestData = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:wbim=\"http://WBImpuestos/\">
            <soapenv:Header/>
            <soapenv:Body>
            <wbim:compraventa>
                <!--Optional:-->
                    <name>
                    " . $data . "
                    </name>
                </wbim:compraventa>
            </soapenv:Body>
            </soapenv:Envelope>";

            $action = "compraventa";
            $headers = [
                'Method: POST',
                'Connection: Keep-Alive',
                'User-Agent: PHP-SOAP-CURL',
                'Content-Type: text/xml; charset=utf-8',
                'SOAPcAtion: compraventa',
            ];

            $ch = curl_init($endpoint);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $requestData);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);

            $xmlString = curl_exec($ch);
            $err_status = curl_errno($ch);

            if ($err_status !== 0) {
                // Manejar el error de cURL
                return "Error en la solicitud cURL: " . curl_error($ch);
            } else {
                // Extraer el string JSON de la cadena XML
                preg_match('/<return>(.*?)<\/return>/', $xmlString, $matches);
                $jsonString = $matches[1];

                // Reemplazar las entidades HTML por caracteres correspondientes
                $jsonString = html_entity_decode($jsonString);

                //echo json_decode($jsonString);
				return $jsonString;
			}
			return $data;
    }
}
    $enviar_factura = new EnviarFactura();
    $json = "";
    $res = $enviar_factura->enviar();
    echo $res;
    echo "hola";

